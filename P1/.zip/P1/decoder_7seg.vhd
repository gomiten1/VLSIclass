----------------------------------------------------------------------------------
-- decoder_7seg.vhd
-- Convierte un valor BCD de 4 bits al código de 7 segmentos.
-- Configurado para un display de ÁNODO COMÚN ('0' enciende, '1' apaga).
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decoder_7seg is
    Port ( 
        bcd_in      : in  STD_LOGIC_VECTOR (3 downto 0);
        segments_out : out STD_LOGIC_VECTOR (6 downto 0) -- gfedcba
    );
end decoder_7seg;

architecture Behavioral of decoder_7seg is
begin
    with bcd_in select
        segments_out <= 
            "0000001" when "0000", -- 0
            "1001111" when "0001", -- 1
            "0010010" when "0010", -- 2
            "0000110" when "0011", -- 3
            "1001100" when "0100", -- 4
            "0100100" when "0101", -- 5
            "0100000" when "0110", -- 6
            "0001111" when "0111", -- 7
            "0000000" when "1000", -- 8
            "0000100" when "1001", -- 9
            "1111111" when others; -- Apagado para valores no válidos
end Behavioral;