----------------------------------------------------------------------------------
-- clk_divider.vhd
-- Genera un pulso de 100 Hz (cada 10 ms) a partir de un reloj de 50 MHz.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity clk_divider is
    Port ( 
        clk_in        : in  STD_LOGIC;
        reset         : in  STD_LOGIC;
        enable_100hz  : out STD_LOGIC
    );
end clk_divider;

architecture Behavioral of clk_divider is
    -- Para pasar de 50 MHz a 100 Hz, necesitamos contar 50,000,000 / 100 = 500,000 ciclos.
    constant MAX_COUNT : integer := 500000 - 1;
    signal counter : integer range 0 to MAX_COUNT := 0;
begin

    process(clk_in, reset)
    begin
        if reset = '1' then
            counter <= 0;
            enable_100hz <= '0';
        elsif rising_edge(clk_in) then
            if counter = MAX_COUNT then
                counter <= 0;
                enable_100hz <= '1'; -- Genera un pulso de un ciclo de reloj
            else
                counter <= counter + 1;
                enable_100hz <= '0';
            end if;
        end if;
    end process;

end Behavioral;