----------------------------------------------------------------------------------
-- fsm_control.vhd
-- Controla el estado del cronómetro (parado o corriendo) usando los botones.
-- Implementa antirrebote (debouncing) para los botones.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity fsm_control is
    Port ( 
        clk           : in  STD_LOGIC;
        reset_btn     : in  STD_LOGIC; -- Botón de Reset general
        start_pause_btn : in  STD_LOGIC; -- Botón de Start/Pause
        tick_100hz    : in  STD_LOGIC; -- Pulso de habilitación del divisor
        count_enable  : out STD_LOGIC; -- Salida que habilita los contadores
        reset_counters: out STD_LOGIC  -- Salida para resetear los contadores
    );
end fsm_control;

architecture Behavioral of fsm_control is
    type state_type is (IDLE, RUNNING);
    signal current_state : state_type := IDLE;

    -- Señales para antirrebote del botón Start/Pause
    signal btn1_ff1, btn1_ff2, btn1_edge : std_logic := '0';

begin
    -- Proceso de antirrebote para el botón Start/Pause
    debounce_proc: process(clk)
    begin
        if rising_edge(clk) then
            btn1_ff1 <= start_pause_btn;
            btn1_ff2 <= btn1_ff1;
        end if;
    end process;
    
    -- Detector de flanco de subida
    btn1_edge <= btn1_ff1 and not btn1_ff2;

    -- Máquina de estados principal
    fsm_proc: process(clk, reset_btn)
    begin
        if reset_btn = '1' then
            current_state <= IDLE;
        elsif rising_edge(clk) then
            case current_state is
                when IDLE =>
                    if btn1_edge = '1' then
                        current_state <= RUNNING;
                    end if;
                
                when RUNNING =>
                    if btn1_edge = '1' then
                        current_state <= IDLE;
                    end if;
            end case;
        end if;
    end process;

    -- Lógica de salidas
    count_enable <= '1' when current_state = RUNNING and tick_100hz = '1' else '0';
    reset_counters <= reset_btn;

end Behavioral;