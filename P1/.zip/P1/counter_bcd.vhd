----------------------------------------------------------------------------------
-- counter_bcd.vhd
-- Contadores BCD para centésimas, segundos y minutos.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity counter_bcd is
    Port ( 
        clk         : in  STD_LOGIC;
        reset       : in  STD_LOGIC;
        count_en    : in  STD_LOGIC; -- Habilitación desde la FSM
        m1_out      : out STD_LOGIC_VECTOR (3 downto 0); -- Minutos (decenas)
        m0_out      : out STD_LOGIC_VECTOR (3 downto 0); -- Minutos (unidades)
        s1_out      : out STD_LOGIC_VECTOR (3 downto 0); -- Segundos (decenas)
        s0_out      : out STD_LOGIC_VECTOR (3 downto 0); -- Segundos (unidades)
        c1_out      : out STD_LOGIC_VECTOR (3 downto 0); -- Centésimas (decenas)
        c0_out      : out STD_LOGIC_VECTOR (3 downto 0)  -- Centésimas (unidades)
    );
end counter_bcd;

architecture Behavioral of counter_bcd is
    signal m1, m0, s1, s0, c1, c0 : unsigned(3 downto 0) := (others => '0');
begin
    
    process(clk, reset)
    begin
        if reset = '1' then
            c0 <= (others => '0'); c1 <= (others => '0');
            s0 <= (others => '0'); s1 <= (others => '0');
            m0 <= (others => '0'); m1 <= (others => '0');
        elsif rising_edge(clk) then
            if count_en = '1' then
                -- Lógica del contador principal
                if m1 = 5 and m0 = 9 and s1 = 5 and s0 = 9 and c1 = 9 and c0 = 9 then
                    -- Reinicio automático al llegar a 59:59:99
                    c0 <= (others => '0'); c1 <= (others => '0');
                    s0 <= (others => '0'); s1 <= (others => '0');
                    m0 <= (others => '0'); m1 <= (others => '0');
                else
                    -- Incremento de centésimas (unidades)
                    if c0 = 9 then
                        c0 <= (others => '0');
                        -- Incremento de centésimas (decenas)
                        if c1 = 9 then
                            c1 <= (others => '0');
                            -- Incremento de segundos (unidades)
                            if s0 = 9 then
                                s0 <= (others => '0');
                                -- Incremento de segundos (decenas)
                                if s1 = 5 then
                                    s1 <= (others => '0');
                                    -- Incremento de minutos (unidades)
                                    if m0 = 9 then
                                        m0 <= (others => '0');
                                        -- Incremento de minutos (decenas)
                                        m1 <= m1 + 1;
                                    else
                                        m0 <= m0 + 1;
                                    end if;
                                else
                                    s1 <= s1 + 1;
                                end if;
                            else
                                s0 <= s0 + 1;
                            end if;
                        else
                            c1 <= c1 + 1;
                        end if;
                    else
                        c0 <= c0 + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;
    
    -- Asignación a las salidas
    c0_out <= std_logic_vector(c0);
    c1_out <= std_logic_vector(c1);
    s0_out <= std_logic_vector(s0);
    s1_out <= std_logic_vector(s1);
    m0_out <= std_logic_vector(m0);
    m1_out <= std_logic_vector(m1);

end Behavioral;