----------------------------------------------------------------------------------
-- display_mux.vhd
-- Multiplexa los 6 dígitos BCD para mostrarlos en los displays.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity display_mux is
    Port ( 
        clk         : in  STD_LOGIC;
        m1_in, m0_in, s1_in, s0_in, c1_in, c0_in : in STD_LOGIC_VECTOR (3 downto 0);
        anode_sel   : out STD_LOGIC_VECTOR (5 downto 0); -- Control de ánodos
        bcd_to_dec  : out STD_LOGIC_VECTOR (3 downto 0)  -- Salida BCD multiplexada
    );
end display_mux;

architecture Behavioral of display_mux is
    -- Divisor para refresco de display (aprox. 800 Hz)
    constant MUX_CLK_DIV : integer := 62500; -- 50MHz / 800Hz
    signal mux_counter : integer range 0 to MUX_CLK_DIV -1 := 0;
    signal mux_clk     : std_logic := '0';

    -- Contador para seleccionar el dígito
    signal digit_sel : unsigned(2 downto 0) := "000"; -- De 0 a 5
begin
    -- Generador de reloj para el multiplexor
    mux_clk_gen: process(clk)
    begin
        if rising_edge(clk) then
            if mux_counter = MUX_CLK_DIV - 1 then
                mux_counter <= 0;
                mux_clk <= not mux_clk;
            else
                mux_counter <= mux_counter + 1;
            end if;
        end if;
    end process;
    
    -- Proceso de multiplexación
    mux_process: process(mux_clk)
    begin
        if rising_edge(mux_clk) then
            digit_sel <= digit_sel + 1;
            if digit_sel = 5 then
                digit_sel <= (others => '0');
            end if;
            
            case digit_sel is
                when "000" => -- Centésimas (unidades)
                    anode_sel <= "111110";
                    bcd_to_dec <= c0_in;
                when "001" => -- Centésimas (decenas)
                    anode_sel <= "111101";
                    bcd_to_dec <= c1_in;
                when "010" => -- Segundos (unidades)
                    anode_sel <= "111011";
                    bcd_to_dec <= s0_in;
                when "011" => -- Segundos (decenas)
                    anode_sel <= "110111";
                    bcd_to_dec <= s1_in;
                when "100" => -- Minutos (unidades)
                    anode_sel <= "101111";
                    bcd_to_dec <= m0_in;
                when "101" => -- Minutos (decenas)
                    anode_sel <= "011111";
                    bcd_to_dec <= m1_in;
                when others =>
                    anode_sel <= "111111";
                    bcd_to_dec <= "1111";
            end case;
        end if;
    end process;

end Behavioral;