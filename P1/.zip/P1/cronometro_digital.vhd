----------------------------------------------------------------------------------
-- cronometro_digital.vhd (Top Level)
-- Módulo principal que integra todos los componentes del cronómetro.
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity cronometro_digital is
    Port ( 
        CLK_50MHZ     : in  STD_LOGIC;
        BTN1_START_PAUSE : in  STD_LOGIC;
        BTN2_RESET    : in  STD_LOGIC;
        ANODES_OUT    : out STD_LOGIC_VECTOR (5 downto 0);
        SEGMENTS_OUT  : out STD_LOGIC_VECTOR (6 downto 0)
    );
end cronometro_digital;

architecture Structural of cronometro_digital is
    -- Señales internas para conectar los módulos
    signal enable_100hz_sig : STD_LOGIC;
    signal count_enable_sig : STD_LOGIC;
    signal reset_counters_sig : STD_LOGIC;
    
    signal m1_sig, m0_sig, s1_sig, s0_sig, c1_sig, c0_sig : STD_LOGIC_VECTOR(3 downto 0);
    signal bcd_mux_out_sig : STD_LOGIC_VECTOR(3 downto 0);
    
begin
    -- Instancia del divisor de reloj
    clk_divider_inst : entity work.clk_divider
        port map (
            clk_in       => CLK_50MHZ,
            reset        => BTN2_RESET,
            enable_100hz => enable_100hz_sig
        );
        
    -- Instancia de la máquina de estados de control
    fsm_control_inst : entity work.fsm_control
        port map (
            clk            => CLK_50MHZ,
            reset_btn      => BTN2_RESET,
            start_pause_btn => BTN1_START_PAUSE,
            tick_100hz     => enable_100hz_sig,
            count_enable   => count_enable_sig,
            reset_counters => reset_counters_sig
        );
        
    -- Instancia de los contadores BCD
    counter_bcd_inst : entity work.counter_bcd
        port map (
            clk      => CLK_50MHZ,
            reset    => reset_counters_sig,
            count_en => count_enable_sig,
            m1_out   => m1_sig,
            m0_out   => m0_sig,
            s1_out   => s1_sig,
            s0_out   => s0_sig,
            c1_out   => c1_sig,
            c0_out   => c0_sig
        );
        
    -- Instancia del multiplexor de displays
    display_mux_inst : entity work.display_mux
        port map (
            clk        => CLK_50MHZ,
            m1_in      => m1_sig,
            m0_in      => m0_sig,
            s1_in      => s1_sig,
            s0_in      => s0_sig,
            c1_in      => c1_sig,
            c0_in      => c0_sig,
            anode_sel  => ANODES_OUT,
            bcd_to_dec => bcd_mux_out_sig
        );
        
    -- Instancia del decodificador BCD a 7 segmentos
    decoder_7seg_inst : entity work.decoder_7seg
        port map (
            bcd_in       => bcd_mux_out_sig,
            segments_out => SEGMENTS_OUT
        );

end Structural;